
def Config():
	gmail_user = 'gmail id' # Gmail Username
	gmail_pwd = 'Password' #Gmail Password
	gmail_config = (gmail_user, gmail_pwd)
	return gmail_config
